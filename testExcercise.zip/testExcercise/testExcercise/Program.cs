﻿
using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Linq;


namespace testExcercise
{
    class Program
    {

        static void Main()
        {


            List<Teacher> list_teachers = new List<Teacher>();
            List<courses> list_courses = new List<courses>();
            List<student> list_students = new List<student>();
            Teacher obj = new Teacher();
            courses c = new courses();
            student std = new student();
            string dummyCour_id = "";

            ///////////////////////File Reading////////////////////////////////

            List<string> lines = File.ReadAllLines(@"C:\Users\fatim\OneDrive\Desktop\TestExcercise.txt").ToList();
            foreach (var line in lines)
            {


                String[] separator = { ": " };
                String[] sep = line.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                if (sep.Length == 0)
                {
                    sep = new String[1];
                    sep[0] = "dummy"; // there is nothing on line
                }

                List<char> commaString = new List<char>();
                sep[0] = sep[0].TrimStart();


                ///////////// Storing Teacher Information///////////////


                if (sep[0] == "StaffID")
                {
                    obj.staff_id = sep[1];

                }

                if (sep[0] == "T_Name")
                {

                    obj.name = sep[1];

                }


                if (sep[0].Equals("Qualifications"))
                {

                    String qual = " ";
                    int j = 0;
                    for (int i = 0; i < line.Length; i++)
                    {


                        if (line.ElementAt(i) == '[')
                        {

                            qual = line.Remove(0, i + 2);
                            qual = qual.Replace(']', ' ');

                        }
                    }

                    String[] qualificationArray = null;
                    qualificationArray = qual.Split(',');

                    obj.qualifications.Clear();
                    foreach (var item in qualificationArray)
                    {


                        obj.qualifications.Add(item);


                    }



                    list_teachers.Add(obj);
                    obj = new Teacher();
                }



                ////////////////////////////CoursesInformation////////////////////////////


                if (sep[0] == "ID")
                {
                    c.Course_id = sep[1];

                }


                if (sep[0] == "Title")
                {
                    c.title = sep[1];

                }


                if (sep[0] == "TotalMarks")
                {
                    c.total_marks = sep[1];

                    list_courses.Add(c);
                    c = new courses();




                }




                //////////////////////////////Student Information//////////////////////////

                if (sep[0] == "StudentID")
                {
                    std = new student();
                    list_students.Add(std);

                    std.student_id = sep[1];


                }

                if (sep[0] == "Name")
                {

                    std.name = sep[1];

                }

                if (sep[0] == ("Course"))
                {

                    dummyCour_id = sep[1];

                }

                if (sep[0] == "Instructors")
                {


                    String qual = " ";
                   
                    for (int i = 0; i < line.Length; i++)
                    {


                        if (line.ElementAt(i) == '[')
                        {

                            qual = line.Remove(0, i + 1);
                           

                            qual = qual.Trim(']');
                        }
                    }
              
                    String[] qualificationArray = null;
                    qualificationArray = qual.Split(',');

                    obj.qualifications.Clear();

                    foreach (var respectcourse in list_courses)
                    {
                        if (respectcourse.AasssignedTeacher.Count != 0)
                        {

                        }
                        else
                        {
                            if (dummyCour_id == respectcourse.Course_id)

                            {

                                  
                                foreach (var teachwe in qualificationArray)

                                {

                                    foreach (var teachers in list_teachers)

                                    {
                                        if (teachwe == teachers.staff_id)
                                        {

                                            respectcourse.AasssignedTeacher.Add(teachers);
                                        }
                                    }
                                }

                            }
                        }
                    }
                    qualificationArray = null;
                }

                if (sep[0] == "Marks")
                {
                    std.CourseAndMarks.Add(new KeyValuePair<string, string>(dummyCour_id, sep[1]));

                }





            }
      

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            foreach (var item in list_students)
            {

                foreach (var obtmarks in item.CourseAndMarks)
                {
                    foreach (var totmarks in list_courses)
                    {
                        if (obtmarks.Key == totmarks.Course_id)
                        {
                            if (int.Parse(obtmarks.Value) < int.Parse(totmarks.total_marks) * 0.60)
                            {
                                Console.WriteLine("Student " + item.name + " was taught the course " + obtmarks.Key + " by instructors ");
                                foreach (var tech in totmarks.AasssignedTeacher)
                                {
                                   
                                    Console.WriteLine(tech.name);
                                }
                                Console.WriteLine(" He failed the exam by getting a score of " + obtmarks.Value + " out of " + totmarks.total_marks);
                                
                            }
                            else
                            {
                                Console.WriteLine("-------------------------------------------------------------");
                                Console.WriteLine("Student " + item.name + " was taught the course " + obtmarks.Key + " by instructors ");
                                foreach (var tech in totmarks.AasssignedTeacher)
                                {
                                   
                                    Console.WriteLine(tech.name);
                                }
                                Console.WriteLine(" He Passed the exam by getting a score of " + obtmarks.Value + " out of " + totmarks.total_marks);
                            }
                        }
                    }

                }

            }

            //////////////////////////////////////////////////////////////////////////////////////////////////

            Console.ReadKey();


        }
    }
}
