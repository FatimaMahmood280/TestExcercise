﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testExcercise
{
    class courses
    {

        public string Course_id;
        public string title;
        public string total_marks;
        public List<Teacher> AasssignedTeacher = new List<Teacher>();



        public courses() { }
        public void show()
        {


            

            Console.WriteLine("Course_id:{0}  Title:{1} Marks:{2}", Course_id, title,total_marks);

            

        }



    }


}
