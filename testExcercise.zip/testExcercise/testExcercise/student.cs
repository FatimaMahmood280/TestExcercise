﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testExcercise
{

    class student
    {
        public string student_id;
        public string name;
        public List<KeyValuePair<string, string>> CourseAndMarks = new List<KeyValuePair<string, string>>();
       

        public student() { }
        

        public void show_students()
        {

            Console.WriteLine(this.name);

            foreach (var pair in CourseAndMarks)
            {
      
                string s = pair.Value;
     
                Console.WriteLine(s);
            

            }

        }


    }

   




}
