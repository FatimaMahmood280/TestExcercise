﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testExcercise
{
    class Teacher
    {
         public string staff_id;
         public string name;
         public List<string> qualifications=new List<string>();

 

     public Teacher()
        {


        }

        public void displayinfo()
        {
            
            
             Console.WriteLine("staff_id:{0}  Teacher:{1}",staff_id,name);
             foreach(var item in qualifications)
              {
                   Console.WriteLine(item);
             }
         
        }



        
    }

   
}
